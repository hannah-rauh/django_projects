from django.contrib import admin

from stars.models import Type, Star

# Register your models here.

admin.site.register(Type)
admin.site.register(Star)